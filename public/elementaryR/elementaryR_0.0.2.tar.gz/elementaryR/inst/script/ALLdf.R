# filename: ALLdf.R
# 
# Produces data frame of top 1000 variance ALL probes
#
# -> source('ALLdf.R', echo=TRUE, max=Inf)

options(stringsAsFactors=FALSE) ### NOTE! ###

library(ALL)
library(hgu95av2)
data(ALL)

ALLexpr = data.frame(exprs(ALL))
varns = apply(ALLexpr, 1, var)
ALL1k = ALLexpr[order(varns, decreasing=TRUE),][1:2000,] # Extra
ALL1k$ID = rownames(ALL1k)

hgVar <- function(name, ord=ALL1k$ID) {
  df = data.frame(unlist(as.list(get(paste('hgu95av2', name, sep='')))))
  colnames(df)[1] = name
  df$ID = rownames(df)
  return(df[ !is.na(df[,name]),])
}

mergem <- function(name) merge(hgVar(name), ALL1k, by='ID')

ALL1k = mergem('SYMBOL')
ALL1k = mergem('ENTREZID')
ALL1k = ALL1k[1:1000,] # Clip

save(ALL1k, file='../../data/ALL1k.rda')

info = pData(ALL)
save(info, file='../../data/ALL1k_pData.rda')
