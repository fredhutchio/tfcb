### R code from vignette source 'day2.Rnw'

###################################################
### code chunk number 1: setup
###################################################
options(width=90)


###################################################
### code chunk number 2: day2.Rnw:32-38 (eval = FALSE)
###################################################
## ### Go to your data directory to get these files:
## dataFile = file.choose() # ALL1k.rda
## dataName = load(file=dataFile) # "ALL1k" is the data frame's name
## 
## infoFile = file.choose() # ALL1k_pData.rda
## infoName = load(file=infoFile) # "info" is the data frame's name


###################################################
### code chunk number 3: day2.Rnw:41-48
###################################################
dataFile = system.file("data", 'ALL1k.rda',
  package="elementaryR")
dataName = load(file=dataFile) # ALL1k

infoFile = system.file('data', 'ALL1k_pData.rda',
  package="elementaryR")
infoName = load(file=infoFile) # info


###################################################
### code chunk number 4: day2.Rnw:53-54
###################################################
median(info$age)


###################################################
### code chunk number 5: day2.Rnw:56-57 (eval = FALSE)
###################################################
## ?median


###################################################
### code chunk number 6: day2.Rnw:59-62
###################################################
median(info$age, na.rm=TRUE)
range(info$age, na.rm=TRUE)
quantile(info$age, na.rm=TRUE)


###################################################
### code chunk number 7: day2.Rnw:66-70 (eval = FALSE)
###################################################
## plot(info$age)
## plot(sort(info$age))
## sortedAge = sort(info$age)
## ?plot


###################################################
### code chunk number 8: boxplot (eval = FALSE)
###################################################
## plot(age ~ sex, info)


###################################################
### code chunk number 9: day2.Rnw:86-89 (eval = FALSE)
###################################################
## hist(info$age)
## ?hist
## hist(info$age, br=25)


###################################################
### code chunk number 10: day2.Rnw:93-95
###################################################
xtabs(~sex, data=info, exclude=NA)
xtabs(~sex + remission, data=info, exclude=NA)


###################################################
### code chunk number 11: plot-ages (eval = FALSE)
###################################################
## plot(age ~ sex, info)


###################################################
### code chunk number 12: ttest0
###################################################
t.test(age ~ sex, info)


###################################################
### code chunk number 13: t.test-help (eval = FALSE)
###################################################
## ?t.test


###################################################
### code chunk number 14: ttest1
###################################################
t.test(age ~ sex, info, var.equal=TRUE)


###################################################
### code chunk number 15: lm
###################################################
(fit <- lm(age ~ sex, info))
anova(fit)


###################################################
### code chunk number 16: plot-fit (eval = FALSE)
###################################################
## plot(fit)


###################################################
### code chunk number 17: class
###################################################
class(fit)


###################################################
### code chunk number 18: methods
###################################################
methods(plot)


###################################################
### code chunk number 19: day2.Rnw:158-159 (eval = FALSE)
###################################################
## ?plot.lm


###################################################
### code chunk number 20: predict
###################################################
df = data.frame(sex=c("F", "M"))
predict(fit, df)


###################################################
### code chunk number 21: coef
###################################################
coefficients(fit)


###################################################
### code chunk number 22: bt
###################################################
summary(info[,c("BT", "cyto.normal")])


###################################################
### code chunk number 23: BT
###################################################
old <- levels(info$BT)
new <- substr(old, 1, 1)
(map <- setNames(new, old))


###################################################
### code chunk number 24: map
###################################################
levels(info$BT) <- map
xtabs(~ BT + cyto.normal, info)


###################################################
### code chunk number 25: chisq
###################################################
chisq.test(info$BT, info$cyto.normal)


###################################################
### code chunk number 26: prep
###################################################
m <- as.matrix(ALL1k[, -c(1, 2)])


###################################################
### code chunk number 27: colors
###################################################
library(RColorBrewer)
divergent <- brewer.pal(11, "RdBu")
highlight <- brewer.pal(3, "Set2")[1:2]


###################################################
### code chunk number 28: prcomp
###################################################
tm = t(m)
pc <- prcomp(tm)


###################################################
### code chunk number 29: prcomp-plot
###################################################
color <- highlight[info$BT]
plot(pc$x, col=color, pch=20, cex=2)


###################################################
### code chunk number 30: dist
###################################################
cm <- cor(m)


###################################################
### code chunk number 31: dist
###################################################
d <- dist(cm)


###################################################
### code chunk number 32: hclust
###################################################
cl <- hclust(d)
plot(cl)


###################################################
### code chunk number 33: heatmap
###################################################
color <- highlight[info$BT]
heatmap(cm, ColSideColor=color, col=divergent)


###################################################
### code chunk number 34: kmeans
###################################################
set.seed(123)
cl <- kmeans(t(m), 2)


###################################################
### code chunk number 35: confusion
###################################################
xtabs(~ cl$cluster + info$BT)


