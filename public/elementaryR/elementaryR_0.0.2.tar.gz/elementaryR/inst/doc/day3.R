### R code from vignette source 'day3.Rnw'

###################################################
### code chunk number 1: setup
###################################################
options(width=90)
options(prompt=' ', continue=' ')


###################################################
### code chunk number 2: day3.Rnw:37-40 (eval = FALSE)
###################################################
## x = 2 + 2
## cat(x, '\n')
## x = 7


###################################################
### code chunk number 3: day3.Rnw:77-83
###################################################
matrixMaker <- function(m, n) {
  x = matrix(floor(runif(m*n, min=0, max=10)), nrow=m, ncol=n)
  colnames(x) = LETTERS[1:n]
  rownames(x) = 1:m
  return(x)
}


###################################################
### code chunk number 4: day3.Rnw:86-87
###################################################
matrixMaker(4,3) # 4 rows, 3 columns


###################################################
### code chunk number 5: day3.Rnw:117-120
###################################################
set.seed(11)
mx = matrixMaker(10,5)
mx


###################################################
### code chunk number 6: day3.Rnw:125-130
###################################################
apply(mx, 1, sum) # sum values for each 'sample' 1 through 10
apply(mx, 2, sum) # sum values for each 'experiment' A through E

### Create an on-the-fly function for a more complex evaluation
apply(mx, 2, function(x) length(which(x!=0))) # count column non-zero values


###################################################
### code chunk number 7: day3.Rnw:135-147
###################################################
mxl = list(A=mx[,'A'], B=mx[,'B'], C=mx[,'C'], D=mx[,'D'], E=mx[,'E'])
mxl

### use 'lapply' on a 'L'-ist
lapply(mxl, sum) # total score for each exp A through E
lapply(mxl, function(x) length(which(x!=0))) # num. samples with value != 0

lapply(seq(along=mxl), function(k) sum(mxl[[k]]))

### Particular utility of a list -- collect objects of different classes
mxl2 = lapply(seq(ncol(mx)), function(k) list(mx[,k], paste('Sample', LETTERS[k])))
names(mxl2) = tolower(colnames(mx))


###################################################
### code chunk number 8: day3.Rnw:152-157
###################################################
lapply(mxl, sum) 
sapply(mxl, sum) # Operate on list
sapply(mxl, sum, simplify=FALSE)

sqrt(sapply(mxl, sum)) # Continue with additional operations


###################################################
### code chunk number 9: day3.Rnw:162-177
###################################################
if(any(mx==0)) cat('Some values are zero!\n')
if(all(mx!=0)) cat('<NO> values are zero!\n')

if (any(mx==0)) cat('Some values are zero!\n') else cat('<NO> values are zero!\n')

if (any(mx==0)) {
  msg = 'Some values are zero!'
  cat(msg, '\n')
} else {
  msg = '<NO> values are zero!'
  cat(msg, '\n')
}

### Scope of variables assigned within 'if' includes the parent environment:
msg


###################################################
### code chunk number 10: day3.Rnw:182-203
###################################################
for (k in seq(ncol(mx))) {
  u = unique(mx[,k])
  len = length(u)
}

### But!
u
len

### Be careful :)
u = vector('list', ncol(mx))
len = vector('integer', ncol(mx))
#
for (k in seq(ncol(mx))) {
  u[[k]] = unique(mx[,k])
  len[k] = length(u[[k]])
}
names(u) = names(len) = colnames(mx)

u
len


###################################################
### code chunk number 11: day3.Rnw:296-304
###################################################
### Scatter plot with title, "toFile" and ... passed as arguments
plotIt <- function(x, y, main='', toFile=FALSE, ...) {
  if(toFile) pdf(file='myPlot.pdf')
  plot(x,y, type='o', main=main, ...)
  abline(h=0, lty=3,col='blue')
  abline(v=0, lty=2, col='red')
  if(toFile) invisible(dev.off())
}


###################################################
### code chunk number 12: day3.Rnw:347-351 (eval = FALSE)
###################################################
## debug(plotIt)
## x = -5:5
## y = log(abs(x))
## plotIt(x, y)


###################################################
### code chunk number 13: day3.Rnw:362-365 (eval = FALSE)
###################################################
## source('http://bioconductor.org/biocLite.R')
## biocLite('edgeR') # For example
## library(edgeR)


###################################################
### code chunk number 14: day3.Rnw:380-381
###################################################
options(prompt='> ', continue='+ ')


