### R code from vignette source 'day4.Rnw'

###################################################
### code chunk number 1: setup
###################################################
options(width=90)


###################################################
### code chunk number 2: input
###################################################
file <- system.file(package="elementaryR", "extdata", "BRFSS-subset.csv",
                    mustWork=TRUE)
brfss <- read.csv(file)


###################################################
### code chunk number 3: simple-plot
###################################################
plot(sqrt(Weight) ~ Height, brfss, main="All Years, Both Sexes")


###################################################
### code chunk number 4: brfss2010
###################################################
brfss2010 <- brfss[brfss$Year == "2010", ]


###################################################
### code chunk number 5: paired-plot
###################################################
opar <- par(mfcol=c(1, 2))
plot(sqrt(Weight) ~ Height, brfss2010[brfss2010$Sex == "Female", ],
     main="2010, Female")
plot(sqrt(Weight) ~ Height, brfss2010[brfss2010$Sex == "Male", ],
     main="2010, Male")
par(mfcol=c(1, 1))


###################################################
### code chunk number 6: lattice
###################################################
library(lattice)


###################################################
### code chunk number 7: lattice-pair
###################################################
xyplot(sqrt(Weight) ~ Height | Sex, brfss2010)


###################################################
### code chunk number 8: lattice-density
###################################################
densityplot(~sqrt(Weight), brfss2010, group=Sex, plot.points=FALSE)


###################################################
### code chunk number 9: lattice-bwplot
###################################################
bwplot(sqrt(Weight) ~ factor(Year) | Sex, brfss)


###################################################
### code chunk number 10: lattice-violin
###################################################
bwplot(sqrt(Weight) ~ factor(Year) | Sex, brfss, panel=panel.violin)


###################################################
### code chunk number 11: lattice-panel
###################################################
xyplot(sqrt(Weight) ~ Height|Sex, brfss2010,
    panel = function(x, y, ...) {
        panel.xyplot(x, y, ...)
        panel.points(median(x, na.rm=TRUE), median(y, na.rm=TRUE), 
            cex=2, pch=20, col="red")
    },
    type=c("p", "g", "r"), lwd=2, col.line="red", xlim=c(120, 210))


###################################################
### code chunk number 12: ggplot
###################################################
library(ggplot2)


###################################################
### code chunk number 13: ggplot-density (eval = FALSE)
###################################################
## ggplot(brfss2010) + geom_density() + aes(sqrt(Weight), fill=Sex)


###################################################
### code chunk number 14: ggplot-density
###################################################
ggplot(brfss2010) + 
    geom_density(alpha=.5) + 
    aes(sqrt(Weight), fill=Sex) +
    scale_x_continuous(name="Square root of Weight (kg)") +
    scale_y_continuous(name="Density") +
    theme(legend.position="top")


