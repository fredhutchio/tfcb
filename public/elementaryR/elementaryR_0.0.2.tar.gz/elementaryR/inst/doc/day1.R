### R code from vignette source 'day1.Rnw'

###################################################
### code chunk number 1: setup
###################################################
options(width=90)


###################################################
### code chunk number 2: day1.Rnw:133-136
###################################################
2
2 + 2
2^10


###################################################
### code chunk number 3: day1.Rnw:139-142
###################################################
c(2, 4, 3)
mean(c(2, 4, 3))
sd(c(2, 4, 3))


###################################################
### code chunk number 4: day1.Rnw:145-148
###################################################
x = c(2, 4, 3)
y = 2 + 2
x/y


###################################################
### code chunk number 5: day1.Rnw:163-166 (eval = FALSE)
###################################################
## filename = file.choose() # Go to the data directory to get the file
## info = read.delim(filename)
## ?read.delim


###################################################
### code chunk number 6: day1.Rnw:169-173
###################################################
filename = system.file('extdata', 'ALLannotationFromExcel.txt',
  package="elementaryR")
info = read.delim(filename)
?read.delim


###################################################
### code chunk number 7: day1.Rnw:177-183
###################################################
class(info)
colnames(info)
dim(info)
head(info)
summary(info$sex)
summary(info$cyto.normal)


###################################################
### code chunk number 8: day1.Rnw:193-194
###################################################
info[1:10, 3:4]


###################################################
### code chunk number 9: day1.Rnw:196-198 (eval = FALSE)
###################################################
## info[1:10, ] # What do these do?
## info[, 3:4]


###################################################
### code chunk number 10: day1.Rnw:201-203
###################################################
head(info[, 3:5])
tail(info[, 3:5])


###################################################
### code chunk number 11: day1.Rnw:206-207 (eval = FALSE)
###################################################
## ?head


###################################################
### code chunk number 12: day1.Rnw:213-215
###################################################
head(info$age)
head(info$sex)


###################################################
### code chunk number 13: day1.Rnw:218-221
###################################################
info$age[info$age > 21]
info$sex[info$sex == 'M']
info$sex[info$sex == 'M' & !is.na(info$sex)]


###################################################
### code chunk number 14: day1.Rnw:230-244
###################################################
x = 28.1/7
x
class(x)
log2(x) # A commonly used transformation: log base 2
log(x) # What is the base of this logarithm?
sqrt(x) # What is this transform?
y = 10 > 3
y
class(y)
z = substr('Hi there!', 1, 5)
z
class(z)
class(info$sex)
levels(info$sex)


###################################################
### code chunk number 15: day1.Rnw:255-261 (eval = FALSE)
###################################################
## ?write.table
## idx = with(info, cyto.normal==TRUE & !is.na(cyto.normal))
## write.table(info[idx,], file='cytoNormal.txt', sep='\t',
##             row.names=FALSE, quote=FALSE)
## write.table(info[idx,], file='cytoNormal.csv', sep=',', 
##             row.names=FALSE, quote=FALSE)


